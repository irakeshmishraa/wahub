<?php
namespace App\Services;

use App\Models\Tenant;
use App\Models\WhatsappSetting;
use App\Models\Message;
use App\Models\Template;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class WhatsAppCloudApiService
{
    private const GRAPH_URL  = 'https://graph.facebook.com/v20.0';
    private const TIMEOUT    = 30;

    private WhatsappSetting $settings;

    public function __construct(Tenant $tenant)
    {
        $this->settings = $tenant->whatsappSetting;
        if (!$this->settings) {
            throw new \RuntimeException("WhatsApp not configured for tenant {$tenant->id}");
        }
    }

    // ----------------------------------------------------------------
    // CONNECTION & HEALTH
    // ----------------------------------------------------------------

    public function validateToken(): array
    {
        $resp = Http::timeout(self::TIMEOUT)
            ->withToken($this->settings->access_token)
            ->get(self::GRAPH_URL . '/me');

        return [
            'valid' => $resp->successful(),
            'data'  => $resp->json(),
        ];
    }

    public function healthCheck(): array
    {
        try {
            $resp = Http::timeout(self::TIMEOUT)
                ->withToken($this->settings->access_token)
                ->get(self::GRAPH_URL . "/{$this->settings->phone_number_id}",
                    ['fields' => 'display_phone_number,verified_name,quality_rating,status']);

            $data = $resp->json();
            $status = $resp->successful() ? 'healthy' : 'degraded';

            $this->settings->update([
                'health_status'    => $status,
                'last_health_check'=> now(),
                'quality_rating'   => $data['quality_rating'] ?? null,
            ]);

            return ['status' => $status, 'data' => $data];
        } catch (\Exception $e) {
            $this->settings->update(['health_status' => 'disconnected']);
            return ['status' => 'disconnected', 'error' => $e->getMessage()];
        }
    }

    // ----------------------------------------------------------------
    // SEND MESSAGE — TEXT
    // ----------------------------------------------------------------

    public function sendText(string $phone, string $text, ?string $replyToWaId = null): array
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'recipient_type'    => 'individual',
            'to'                => $this->normalizePhone($phone),
            'type'              => 'text',
            'text'              => ['body' => $text, 'preview_url' => false],
        ];
        if ($replyToWaId) {
            $payload['context'] = ['message_id' => $replyToWaId];
        }
        return $this->sendRequest($payload);
    }

    // ----------------------------------------------------------------
    // SEND MESSAGE — TEMPLATE
    // ----------------------------------------------------------------

    public function sendTemplate(
        string $phone,
        string $templateName,
        string $language = 'en',
        array $components = []
    ): array {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $this->normalizePhone($phone),
            'type'              => 'template',
            'template'          => [
                'name'       => $templateName,
                'language'   => ['code' => $language],
                'components' => $components,
            ],
        ];
        return $this->sendRequest($payload);
    }

    /**
     * Build template components array from a Template model + variable values
     */
    public function buildTemplateComponents(Template $template, array $variables = []): array
    {
        $components = [];

        // Header media
        if (in_array($template->header_type, ['image','video','document'])) {
            $components[] = [
                'type'       => 'header',
                'parameters' => [[
                    'type'  => $template->header_type,
                    $template->header_type => ['link' => $template->header_media_url],
                ]],
            ];
        }

        // Body variables
        if (!empty($variables)) {
            $params = array_map(fn($v) => ['type' => 'text', 'text' => $v], $variables);
            $components[] = ['type' => 'body', 'parameters' => $params];
        }

        // Buttons (dynamic URL, copy_code)
        if ($template->buttons) {
            foreach ($template->buttons as $i => $btn) {
                if ($btn['type'] === 'URL' && isset($btn['dynamic'])) {
                    $components[] = [
                        'type'       => 'button',
                        'sub_type'   => 'url',
                        'index'      => $i,
                        'parameters' => [['type' => 'text', 'text' => $btn['url_suffix'] ?? '']],
                    ];
                }
                if ($btn['type'] === 'COPY_CODE') {
                    $components[] = [
                        'type'       => 'button',
                        'sub_type'   => 'COPY_CODE',
                        'index'      => $i,
                        'parameters' => [['type' => 'coupon_code', 'coupon_code' => $btn['coupon'] ?? '']],
                    ];
                }
            }
        }

        return $components;
    }

    // ----------------------------------------------------------------
    // SEND MESSAGE — MEDIA
    // ----------------------------------------------------------------

    public function sendMedia(string $phone, string $type, string $mediaUrl, ?string $caption = null): array
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $this->normalizePhone($phone),
            'type'              => $type,
            $type               => array_filter([
                'link'    => $mediaUrl,
                'caption' => $caption,
            ]),
        ];
        return $this->sendRequest($payload);
    }

    // ----------------------------------------------------------------
    // TEMPLATE MANAGEMENT
    // ----------------------------------------------------------------

    public function submitTemplate(Template $template): array
    {
        $resp = Http::timeout(self::TIMEOUT)
            ->withToken($this->settings->access_token)
            ->post(self::GRAPH_URL . "/{$this->settings->waba_id}/message_templates",
                $template->buildPayload());

        $data = $resp->json();

        if ($resp->successful()) {
            $template->update([
                'meta_template_id' => $data['id'],
                'status'           => 'pending',
                'submitted_at'     => now(),
            ]);
        }

        return ['success' => $resp->successful(), 'data' => $data];
    }

    public function fetchTemplateStatus(Template $template): array
    {
        if (!$template->meta_template_id) {
            return ['error' => 'No meta template ID'];
        }

        $resp = Http::timeout(self::TIMEOUT)
            ->withToken($this->settings->access_token)
            ->get(self::GRAPH_URL . "/{$template->meta_template_id}",
                ['fields' => 'status,rejected_reason,quality_score']);

        $data = $resp->json();

        if ($resp->successful()) {
            $status = strtolower($data['status'] ?? 'pending');
            $template->update([
                'status'           => $status,
                'rejection_reason' => $data['rejected_reason'] ?? null,
                'approved_at'      => $status === 'approved' ? now() : null,
            ]);
        }

        return ['success' => $resp->successful(), 'data' => $data];
    }

    public function syncAllTemplates(): int
    {
        $resp = Http::timeout(self::TIMEOUT)
            ->withToken($this->settings->access_token)
            ->get(self::GRAPH_URL . "/{$this->settings->waba_id}/message_templates",
                ['fields' => 'id,name,status,rejected_reason,quality_score,components']);

        if (!$resp->successful()) return 0;

        $count = 0;
        foreach ($resp->json('data', []) as $tpl) {
            Template::where('tenant_id', $this->settings->tenant_id)
                ->where('meta_template_id', $tpl['id'])
                ->update([
                    'status'           => strtolower($tpl['status']),
                    'rejection_reason' => $tpl['rejected_reason'] ?? null,
                ]);
            $count++;
        }
        return $count;
    }

    // ----------------------------------------------------------------
    // MARK MESSAGE READ
    // ----------------------------------------------------------------

    public function markRead(string $waMessageId): void
    {
        Http::timeout(5)
            ->withToken($this->settings->access_token)
            ->post(self::GRAPH_URL . "/{$this->settings->phone_number_id}/messages", [
                'messaging_product' => 'whatsapp',
                'status'            => 'read',
                'message_id'        => $waMessageId,
            ]);
    }

    // ----------------------------------------------------------------
    // UPLOAD MEDIA
    // ----------------------------------------------------------------

    public function uploadMedia(string $filePath, string $mimeType): array
    {
        $resp = Http::timeout(60)
            ->withToken($this->settings->access_token)
            ->attach('file', fopen($filePath, 'r'), basename($filePath), ['Content-Type' => $mimeType])
            ->post(self::GRAPH_URL . "/{$this->settings->phone_number_id}/media", [
                'messaging_product' => 'whatsapp',
                'type'              => $mimeType,
            ]);

        return ['success' => $resp->successful(), 'data' => $resp->json()];
    }

    // ----------------------------------------------------------------
    // WEBHOOK VERIFICATION
    // ----------------------------------------------------------------

    public function verifyWebhook(string $mode, string $challenge, string $verifyToken): ?string
    {
        if ($mode === 'subscribe' && $verifyToken === $this->settings->webhook_verify_token) {
            return $challenge;
        }
        return null;
    }

    public function validateWebhookSignature(string $payload, string $signature): bool
    {
        $expected = 'sha256=' . hash_hmac('sha256', $payload, $this->settings->meta_app_secret ?? '');
        return hash_equals($expected, $signature);
    }

    // ----------------------------------------------------------------
    // INTERNAL
    // ----------------------------------------------------------------

    private function sendRequest(array $payload): array
    {
        try {
            $resp = Http::timeout(self::TIMEOUT)
                ->withToken($this->settings->access_token)
                ->post(self::GRAPH_URL . "/{$this->settings->phone_number_id}/messages", $payload);

            $data = $resp->json();

            if (!$resp->successful()) {
                Log::error('WhatsApp API error', ['payload' => $payload, 'response' => $data]);
            }

            return [
                'success'    => $resp->successful(),
                'wa_message_id' => $data['messages'][0]['id'] ?? null,
                'data'       => $data,
            ];
        } catch (\Exception $e) {
            Log::error('WhatsApp API exception', ['error' => $e->getMessage()]);
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    private function normalizePhone(string $phone): string
    {
        // Strip + and spaces, ensure starts with country code
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (str_starts_with($phone, '0')) {
            $phone = '91' . ltrim($phone, '0'); // default India
        }
        return $phone;
    }
}
